FRIEND MASTI HUB - HOME SCREEN VERSION

1. ZIP extract karo.
2. App ko kisi HTTPS/static hosting par upload karo.
3. Android Chrome me app ka web address kholo.
4. Chrome ke 3-dot menu par tap karo.
5. "Add to Home screen" ya "Install app" select karo.
6. Add/Install dabao.
7. Ab "Friend Masti Hub" Home Screen par app icon ke saath milega.

NOTE:
- Direct file:// se ZIP ke andar index.html kholne par Home Screen install option aa sakta hai ki nahi, ye browser par depend karta hai.
- PWA install ke liye HTTPS hosting recommended hai.
- BGMI/Free Fire MAX rooms actual games ko control nahi karte; ye companion room manager hai.
